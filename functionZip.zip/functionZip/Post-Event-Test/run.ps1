using namespace System.Net

param($EventGridEvent, $TriggerMetadata)

Write-Host "Event received:"

# Authentifizieren mit Managed Identity
Connect-AzAccount -Identity

# Azure Arc VM Details (subscriptionId/resourceGroup/...)
$eventCorrelation = $EventGridEvent.data.CorrelationId
$parts = $eventCorrelation.split("/")
$subscriptionId = $parts[2]
$resourceGroup = $parts[4]
$maintenanceConfigName = $parts[8]
$maintenanceConfigurationId = $EventGridEvent.data.MaintenanceConfigurationId
$maintenanceType = $EventGridEvent.eventType
Write-Host "MaintenacneConfigName: $maintenanceConfigName"
Write-Host "MaintenanceConfigurationId: $maintenanceConfigurationId"
Write-Host "Maintenacttype: $maintenanceType"
# Setze das richtige Subscription Contextsup
Set-AzContext -SubscriptionId $subscriptionId

#Liste alle VMs der ResourceGroup
$vms = Get-AzConnectedMachine -ResourceGroupName $resourceGroup

#Hauptteil: Für jede Vm in der ResourceGroup wird geschaut ob diese Maintenance Configuration dieser Vm assigned ist
foreach ($vm in $vms) {
    $machineName = $vm.Name
    $VmsConfigInfo = Get-AzConfigurationAssignment -ResourceGroupName $resourceGroup -ProviderName "Microsoft.HybridCompute" -ResourceType "machines" -ResourceName $machineName
    $VmsConfigIds = $VmsConfigInfo.MaintenanceConfigurationId
    $VmInConfig = $false
    foreach ($VmConfigId in $VmsConfigIds) {
        if($VmConfigId -eq $maintenanceConfigurationId) {
            $VmInConfig = $true
        }
    }
    #Hier wird für jede VM das Script ausgeführt welches so heißt wie die Maintenance Configuration + es wird zwischen Pre und Post Maintenance unterschieden
    if($VmInConfig) {
    Write-Output "VM Name: $machineName"
    $storageAccountName = "garatest"
    $containerName = "scripts"
    try {
        Write-Host "Maintenacttype: $maintenanceType"
        if($maintenanceType -eq "Microsoft.Maintenance.PreMaintenanceEvent") {
            $global:blobUri = "https://$storageAccountName.blob.core.windows.net/$containerName/pre_$maintenanceConfigName.ps1"
        } else {
            $global:blobUri = "https://$storageAccountName.blob.core.windows.net/$containerName/post_$maintenanceConfigName.ps1"
        }
    }
    catch {
        Write-Error "No Script existing for VMname: $_"
    }
    try {
        Write-Host "Bloburi: $blobUri"
        $scriptBlock = Invoke-RestMethod -Uri $blobUri
        Write-Output "Skriptinhalt geladen"
        Write-Output $scriptBlock
    }
    catch {
        Write-Error "Fehler bei BlobStorageLaden: $_"
    }

    try {
        $job = New-AzConnectedMachineRunCommand -ResourceGroupName $resourceGroup -MachineName $machineName -Location "germanywestcentral" -RunCommandName "RunCommand-$(Get-Random)" -SourceScript $scriptBlock -AsJob
        
        Write-Host "RunCommand-Job gestartet. Job-ID: $($job.Id)"
    } 
    catch {
        Write-Error "Fehler beim Starten des RunCommand-Jobs: $_"
        throw
    }
    } else {
        Write-Host "$($vm.Name) ist nicht in der Maintenance Configuration"
    }
    
}

Write-Host "NachdemRunCommand"

